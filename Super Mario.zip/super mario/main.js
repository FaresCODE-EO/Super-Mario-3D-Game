import * as THREE from 'three';
import { Level } from './js/Level.js';
import { Player } from './js/Player.js';
import { CameraController } from './js/Camera.js';
import { AssetManager } from './js/AssetManager.js';

// Init Asset Manager
const assetManager = new AssetManager();
// assetManager.queueDownload('assets/mario/Mario.obj');
// assetManager.queueDownload('assets/textures/0xbc4e9ae5.png');
assetManager.queueDownload('assets/lm3_-_mario_mario_thats_his_full_name.glb'); // New Player Asset (Colored)
assetManager.queueDownload('assets/spike_top_super_mario_bros.glb'); // Enemy Asset

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87CEEB);
// scene.fog = new THREE.Fog(0x87CEEB, 10, 50); // Fog removed as requested

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

// Lights
const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
dirLight.position.set(10, 20, 10);
dirLight.castShadow = true;
dirLight.shadow.camera.top = 20;
dirLight.shadow.camera.bottom = -20;
dirLight.shadow.camera.left = -20;
dirLight.shadow.camera.right = 20;
dirLight.shadow.mapSize.width = 2048;
dirLight.shadow.mapSize.height = 2048;
scene.add(dirLight);

// Global refs
let level, player, cameraController, clock;

// Start Game Function
function startGame() {
    document.getElementById('loading-screen').style.display = 'none';
    // document.getElementById('start-screen').style.display = 'block'; // OLD
    // Show Main Menu instead

    // Note: The main menu is visible by default in HTML? No, verify CSS.
    // HTML structure changed, so we don't need to force show '#start-screen'.
    // We just ensure 'loading-screen' is gone.
    const menu = document.getElementById('main-menu');
    if (menu) menu.style.display = 'block';

    level = new Level(scene, assetManager);
    player = new Player(scene, camera, level.platforms);

    // Set Mesh from AssetManager
    // const marioMesh = assetManager.getAsset('assets/mario/Mario.obj');
    // const marioTexture = assetManager.getAsset('assets/textures/0xbc4e9ae5.png');
    // player.setMesh(marioMesh, marioTexture);

    const playerAsset = assetManager.getAsset('assets/lm3_-_mario_mario_thats_his_full_name.glb');
    if (playerAsset) {
        player.setMesh(playerAsset.scene);
    } else {
        console.error("Player Asset Not Found");
    }

    cameraController = new CameraController(camera, player);
    clock = new THREE.Clock();

    animate();
}

// Load Assets
assetManager.downloadAll(() => {
    console.log("All Assets Loaded");
    startGame();
});

// Resize handler
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

// Loop
function animate() {
    requestAnimationFrame(animate);

    if (clock && player && level) {
        const dt = clock.getDelta();
        player.update(dt);
        level.update(dt, player);
        cameraController.update();
    }

    renderer.render(scene, camera);
}

// --- Menu Hub Logic ---

const menu = document.getElementById('main-menu');
if (menu) {
    document.getElementById('btn-play').addEventListener('click', () => {
        menu.style.display = 'none';
        level.loadLevel(1);
    });

    document.getElementById('btn-levels').addEventListener('click', () => {
        document.getElementById('menu-buttons').style.display = 'none';
        document.getElementById('level-select-panel').style.display = 'block';
    });

    document.getElementById('btn-controls').addEventListener('click', () => {
        const p = document.getElementById('controls-panel');
        p.style.display = p.style.display === 'none' ? 'block' : 'none';
    });

    document.getElementById('btn-back').addEventListener('click', () => {
        document.getElementById('level-select-panel').style.display = 'none';
        document.getElementById('menu-buttons').style.display = 'block';
    });

    document.querySelectorAll('.lvl-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const lvl = parseInt(e.target.dataset.lvl);
            menu.style.display = 'none';
            level.loadLevel(lvl);
        });
    });
}

document.addEventListener('level-complete', (e) => {
    const currentLevel = e.detail.level;
    const banner = document.getElementById('level-complete-screen');
    const title = document.getElementById('level-title');

    title.innerText = `Level ${currentLevel} Complete!`;
    banner.style.display = 'block';

    // Setup Next Level Button
    const btn = document.getElementById('next-level-btn');
    const nextLevelAction = () => {
        if (banner.style.display === 'none') return; // Prevent double trigger
        banner.style.display = 'none';
        level.loadLevel(currentLevel + 1);
        player.mesh.position.set(0, 5, 0);
        player.velocity.set(0, 0, 0);
        player.resetKeys(); // Double safety
    };

    btn.onclick = nextLevelAction;

    // Allow Enter key to trigger next level
    const enterHandler = (k) => {
        if (k.code === 'Enter') {
            nextLevelAction();
            window.removeEventListener('keydown', enterHandler);
        }
    };
    window.addEventListener('keydown', enterHandler);
});

// Basic Start on Enter for Menu
window.addEventListener('keydown', (e) => {
    const menu = document.getElementById('main-menu');
    // If Enter pressed on menu, play game
    if (e.code === 'Enter' && menu && menu.style.display !== 'none') {
        // Only if not in sub-menus? Simplified: Just play.
        menu.style.display = 'none';
        // Check if level already loaded? Default to 1 if we just started
        if (level.currentLevelIndex === 1) level.loadLevel(1);
    }
});
