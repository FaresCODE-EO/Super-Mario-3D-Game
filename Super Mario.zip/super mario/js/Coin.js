import * as THREE from 'three';

export class Coin {
    constructor(scene, x, y, z) {
        this.scene = scene;
        this.mesh = null;
        this.collected = false;
        this.rotationSpeed = 3;

        this.init(x, y, z);
    }

    init(x, y, z) {
        const geometry = new THREE.CylinderGeometry(0.5, 0.5, 0.1, 16);
        const material = new THREE.MeshPhongMaterial({
            color: 0xFFD700,
            specular: 0xFFFFFF,
            shininess: 50
        });
        this.mesh = new THREE.Mesh(geometry, material);
        this.mesh.position.set(x, y, z);
        this.mesh.rotation.x = Math.PI / 2; // Face forward
        this.mesh.rotation.z = Math.PI / 2; // Upright
        this.mesh.castShadow = true;

        this.scene.add(this.mesh);
    }

    update(dt) {
        if (!this.mesh || this.collected) return;
        this.mesh.rotation.x += this.rotationSpeed * dt;
    }

    checkCollision(playerBox) {
        if (this.collected) return false;
        const coinBox = new THREE.Box3().setFromObject(this.mesh);
        if (coinBox.intersectsBox(playerBox)) {
            this.collect();
            return true;
        }
        return false;
    }

    collect() {
        this.collected = true;
        this.alertCollection();
        this.scene.remove(this.mesh);
    }

    alertCollection() {
        // Dispatch custom event or just update global score if accessible
        // For simplicity, we'll let the Level handle the score update return
    }
}
