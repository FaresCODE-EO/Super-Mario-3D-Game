import * as THREE from 'three';

export class CameraController {
    constructor(camera, player) {
        this.camera = camera;
        this.player = player;

        // Standard Third Person Offset (Lower angle, behind player)
        this.offset = new THREE.Vector3(0, 6, 14);
        this.lookAtOffset = new THREE.Vector3(0, 2, 0);
        this.cameraSpeed = 0.2;
    }

    update() {
        if (!this.player.mesh) return;

        const targetPosition = this.player.mesh.position.clone().add(this.offset);
        this.camera.position.lerp(targetPosition, this.cameraSpeed);

        const lookTarget = this.player.mesh.position.clone().add(this.lookAtOffset);
        this.camera.lookAt(lookTarget);
    }
}
