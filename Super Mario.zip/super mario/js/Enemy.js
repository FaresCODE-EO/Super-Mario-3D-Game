import * as THREE from 'three';

export class Enemy {
    constructor(scene, x, y, z, patrolDistance = 5, modelAsset = null) {
        this.scene = scene;
        this.mesh = null;
        this.startPos = new THREE.Vector3(x, y, z);
        this.patrolDistance = patrolDistance;
        this.direction = 1;
        this.speed = 2;
        this.modelAsset = modelAsset;

        this.init(x, y, z);
    }

    init(x, y, z) {
        if (this.modelAsset) {
            // Use Loaded GLB
            this.mesh = this.modelAsset.scene.clone(); // GLTFLoader returns object with .scene
            this.mesh.position.set(x, y, z);
            // Apply scale
            this.mesh.scale.set(0.022, 0.022, 0.022); // ~3x Smaller than 0.065

            // Enable shadows for all children
            this.mesh.traverse((child) => {
                if (child.isMesh) {
                    child.castShadow = true;
                    child.receiveShadow = true;
                }
            });
            this.scene.add(this.mesh);
        } else {
            // Fallback: Dragon Composite Shape (Procedural)
            this.mesh = new THREE.Group();
            this.mesh.position.set(x, y, z);
            this.mesh.scale.set(0.65, 0.65, 0.65); // 1.3x Bigger

            // Body
            const bodyGeo = new THREE.CylinderGeometry(0.3, 0.5, 1.5, 8);
            const greenMat = new THREE.MeshPhongMaterial({ color: 0x006400 }); // Dark Green
            const body = new THREE.Mesh(bodyGeo, greenMat);
            body.rotation.x = Math.PI / 2;
            body.castShadow = true;
            this.mesh.add(body);

            // Head (Simplified fallback)
            const headGeo = new THREE.BoxGeometry(0.6, 0.6, 0.8);
            const head = new THREE.Mesh(headGeo, greenMat);
            head.position.set(0, 0.5, 0.8);
            head.castShadow = true;
            this.mesh.add(head);

            this.scene.add(this.mesh);
        }
    }

    update(dt) {
        if (!this.mesh) return;

        // Move
        this.mesh.position.x += this.direction * this.speed * dt;

        // Turn around
        if (Math.abs(this.mesh.position.x - this.startPos.x) > this.patrolDistance) {
            this.direction *= -1;
        }
    }

    checkCollision(playerBox) {
        const enemyBox = new THREE.Box3().setFromObject(this.mesh);
        return enemyBox.intersectsBox(playerBox);
    }
}
