import * as THREE from 'three';
import { Coin } from './Coin.js';
import { Enemy } from './Enemy.js';

export class Level {
    constructor(scene, assetManager) {
        this.scene = scene;
        this.assetManager = assetManager; // Store for retrieving assets
        this.platforms = [];
        this.coins = [];
        this.enemies = [];
        this.score = 0;
        this.currentLevelIndex = 1;
        this.maxLevels = 10;
        this.goalMeshGroup = null; // Track goal to remove it

        this.loadLevel(this.currentLevelIndex);
    }

    clearLevel() {
        // Remove old objects from scene
        this.platforms.forEach(p => {
            // Keep ground if we want, but easier to just clear everything except ground
            if (p.geometry.type !== 'PlaneGeometry') this.scene.remove(p);
        });

        // Fix: Don't replace the array, just clear it so Player keeps the reference
        // However, we pushed 'ground' to it, so we should clear it and re-add ground
        // Or finding ground index... simpler to clear and re-add.
        this.platforms.length = 0;
        // Also remove the specific ground mesh if standard clearing didn't catch it (it does usually if in scene)
        // Find ground by name or reference? I'll just clear scene children that are "Environment" later if needed.
        // For now, the loop above removes platforms. 
        // We also need to remove the "Ground" mesh itself which IS in platforms for Levels 1-5.
        // For Level 6+, Lava is NOT in platforms.
        // So we need to track the environment mesh separately or find it.
        if (this.environmentMesh) {
            this.scene.remove(this.environmentMesh);
            this.environmentMesh = null;
        }

        this.coins.forEach(c => this.scene.remove(c.mesh));
        this.coins = [];

        this.enemies.forEach(e => this.scene.remove(e.mesh));
        this.enemies = [];

        if (this.goalMeshGroup) {
            this.scene.remove(this.goalMeshGroup);
            this.goalMeshGroup = null;
        }

        // Clear Tree Borders
        if (this.borderGroup) {
            this.scene.remove(this.borderGroup);
            this.borderGroup = null;
        }
    }

    loadLevel(levelIndex) {
        this.clearLevel();
        this.currentLevelIndex = levelIndex;
        console.log(`Loading Level ${levelIndex}`);

        // Environment Setup
        if (levelIndex <= 5) {
            // Grass / Normal World
            const groundGeometry = new THREE.PlaneGeometry(100, 100);
            const groundMaterial = new THREE.MeshPhongMaterial({ color: 0x228B22 });
            this.environmentMesh = new THREE.Mesh(groundGeometry, groundMaterial);
            this.environmentMesh.rotation.x = -Math.PI / 2;
            this.environmentMesh.receiveShadow = true;
            this.scene.add(this.environmentMesh);
            this.platforms.push(this.environmentMesh); // Walkable

            this.createWorldBorders();
            this.platformColor = 0x8B4513; // Brown Wood
        } else {
            // Lava / Steel World
            const groundGeometry = new THREE.PlaneGeometry(200, 200); // Bigger ocean of lava
            const groundMaterial = new THREE.MeshPhongMaterial({
                color: 0xff3300,
                emissive: 0xff0000,
                emissiveIntensity: 0.2
            });
            this.environmentMesh = new THREE.Mesh(groundGeometry, groundMaterial);
            this.environmentMesh.rotation.x = -Math.PI / 2;
            this.environmentMesh.position.y = -5; // Sunk down so falling kills you
            this.scene.add(this.environmentMesh);
            // NOT added to platforms -> Fall through -> Death

            // No tree borders in Lava world (maybe walls? or open). Let's keep it open/scary.
            this.platformColor = 0x444444; // Steel Grey
        }

        // Level Configs
        switch (levelIndex) {
            case 1: this.buildLevel1(); break;
            case 2: this.buildLevel2(); break;
            case 3: this.buildLevel3(); break;
            case 4: this.buildLevel4(); break;
            case 5: this.buildLevel5(); break;
            case 6: this.buildLevel6(); break;
            case 7: this.buildLevel7(); break;
            case 8: this.buildLevel8(); break;
            case 9: this.buildLevel9(); break;
            case 10: this.buildLevel10(); break;
            default: alert("You Beat the Game!"); this.currentLevelIndex = 1; this.buildLevel1(); break;
        }
    }

    createWorldBorders() {
        this.borderGroup = new THREE.Group();
        // Place trees along the edge of the 100x100 ground (from -50 to 50)
        // Spacing: every 10 units?
        for (let x = -50; x <= 50; x += 10) {
            this.createTree(x, 0, -50); // Back
            this.createTree(x, 0, 50);  // Front
        }
        for (let z = -50; z <= 50; z += 10) {
            this.createTree(-50, 0, z); // Left
            this.createTree(50, 0, z);  // Right
        }
        this.scene.add(this.borderGroup);
    }

    // --- Level Designs ---

    buildLevel1() {
        // Tutorial: Simple jumps
        this.createPlatform(0, 1, -5, 4, 1, 4);
        this.createPlatform(0, 2, -10, 4, 1, 4);
        this.createPlatform(0, 3, -15, 6, 1, 6); // Goal platform

        this.createCoin(0, 2, -5);
        this.createCoin(0, 3, -10);

        this.createGoal(0, 3.5, -15); // On the platform
    }

    buildLevel2() {
        // Verticality: Stairs
        for (let i = 0; i < 5; i++) {
            this.createPlatform(i * 2, i + 1, -5 - (i * 3), 3, 1, 3);
            this.createCoin(i * 2, i + 2, -5 - (i * 3));
        }
        // Big platform at end
        this.createPlatform(10, 6, -20, 5, 1, 5);
        this.createGoal(10, 6.5, -20);

        this.createEnemy(2, 2.5, -8, 2);
    }

    buildLevel3() {
        // "A lot of objects" - Scattered Islands (Original Layout)
        this.createPlatform(-5, 2, -5, 3, 1, 3);
        this.createPlatform(5, 2, -5, 3, 1, 3);
        this.createPlatform(-8, 4, -10, 3, 1, 3);
        this.createPlatform(8, 4, -10, 3, 1, 3);
        this.createPlatform(0, 3, -8, 2, 1, 2); // Bridge

        this.createPlatform(0, 5, -15, 8, 1, 4); // Main deck
        this.createEnemy(-2, 5.5, -15, 3);
        this.createEnemy(2, 5.5, -15, 3);

        this.createPlatform(0, 6, -22, 4, 1, 4); // Goal
        this.createGoal(0, 6.5, -22);
    }

    buildLevel4() {
        // Parkour: Zig Zag
        this.createPlatform(0, 1, -4, 3, 0.5, 3);
        this.createPlatform(-4, 2, -8, 3, 0.5, 3);
        this.createPlatform(4, 3, -12, 3, 0.5, 3);
        this.createPlatform(-4, 4, -16, 3, 0.5, 3);
        this.createPlatform(0, 5, -20, 5, 1, 5);

        this.createEnemy(0, 5.5, -20, 2);
        this.createGoal(0, 5.5, -20);

        // Coins on jumps
        this.createCoin(-2, 3, -8);
        this.createCoin(2, 4, -12);
    }

    buildLevel5() {
        // Final Challenge: Many objects, high up
        // Spiral staircase
        for (let i = 0; i < 20; i++) {
            const angle = (i / 10) * Math.PI * 2;
            const radius = 10;
            const x = Math.cos(angle) * radius;
            const z = -20 + Math.sin(angle) * radius;
            const y = i * 1.5;

            this.createPlatform(x, y, z, 3, 1, 3);
            if (i % 3 === 0) this.createCoin(x, y + 2, z);
        }

        // Final Platform
        this.createPlatform(0, 30, -20, 5, 1, 5); // Reduced from 15x15 to 5x5 to allow character visibility
        this.createGoal(0, 31.5, -20);
    }

    // --- Helpers ---

    buildLevel6() {
        // Intro to Lava: Simple island hops
        // Start platform
        this.createPlatform(0, 0, 0, 5, 1, 5);

        // Steps over lava
        this.createPlatform(0, 1, -10, 3, 1, 3);
        this.createPlatform(0, 2, -20, 3, 1, 3);
        this.createPlatform(0, 3, -30, 3, 1, 3);

        // Goal
        this.createPlatform(0, 3, -40, 5, 1, 5);
        this.createGoal(0, 4.5, -40);

        this.createCoin(0, 3, -20);
    }

    buildLevel7() {
        // Note: Narrow Beams
        this.createPlatform(0, 0, 0, 5, 1, 5);

        // Long beam
        this.createPlatform(0, 1, -15, 2, 1, 20); // Narrow Z-beam

        // Enemy on beam
        this.createEnemy(0, 1.5, -15, 5);

        this.createPlatform(0, 2, -30, 5, 1, 5);
        this.createGoal(0, 3.5, -30);
    }

    buildLevel8() {
        // Vertical Climb
        this.createPlatform(0, 0, 0, 10, 1, 10);

        const centerY = 2;
        const radius = 8;
        for (let i = 0; i < 8; i++) {
            const angle = i * (Math.PI / 2);
            const x = Math.cos(angle) * radius;
            const z = -20 + Math.sin(angle) * radius;
            this.createPlatform(x, centerY + (i * 1.5), z, 3, 1, 3);
            this.createCoin(x, centerY + (i * 1.5) + 1.5, z);
        }

        this.createPlatform(0, 14, -20, 5, 1, 5);
        this.createGoal(0, 15.5, -20);
    }

    buildLevel9() {
        // Scattered Islands (Hard)
        this.createPlatform(0, 0, 0, 5, 1, 5);

        this.createPlatform(-8, 2, -10, 2, 1, 2);
        this.createPlatform(8, 2, -10, 2, 1, 2);

        this.createPlatform(-12, 4, -20, 2, 1, 2);
        this.createPlatform(12, 4, -20, 2, 1, 2);

        this.createPlatform(0, 6, -30, 8, 1, 8); // Arena
        this.createEnemy(0, 6.5, -30, 3);

        this.createGoal(0, 7.5, -30);
    }

    buildLevel10() {
        // Final Boss Run (Long)
        this.createPlatform(0, 0, 0, 5, 1, 5);

        // Zig Zag over lava
        this.createPlatform(5, 1, -10, 3, 1, 3);
        this.createPlatform(-5, 2, -20, 3, 1, 3);
        this.createPlatform(5, 3, -30, 3, 1, 3);
        this.createPlatform(-5, 4, -40, 3, 1, 3);

        // Final stretch
        this.createPlatform(0, 5, -55, 3, 1, 20); // Long bridge
        this.createEnemy(0, 5.5, -50, 4);
        this.createEnemy(0, 5.5, -60, 4);

        this.createPlatform(0, 6, -75, 8, 1, 8);
        this.createGoal(0, 7.5, -75);
    }

    // --- Helpers ---

    createPlatform(x, y, z, w, h, d) {
        // 1.9x Wider, 1.0x Depth
        const sw = w * 2.0;
        const sh = h * 1;
        const sd = d * 1.0;

        const geometry = new THREE.BoxGeometry(sw, sh, sd);
        const material = new THREE.MeshPhongMaterial({ color: this.platformColor || 0x8B4513 });
        const platform = new THREE.Mesh(geometry, material);
        platform.position.set(x, y, z);
        platform.receiveShadow = true;
        platform.castShadow = true;
        this.scene.add(platform);
        this.platforms.push(platform);
    }

    createTree(x, y, z) {
        // Add to border group if available, else scene
        const group = new THREE.Group();
        group.position.set(x, y, z);
        // group.scale.set(1, 1, 1);

        // Trunk
        const trunkGeo = new THREE.CylinderGeometry(0.5, 0.7, 3, 8);
        const trunkMat = new THREE.MeshPhongMaterial({ color: 0x3d2817 });
        const trunk = new THREE.Mesh(trunkGeo, trunkMat);
        trunk.position.y = 1.5;
        trunk.castShadow = true;
        group.add(trunk);

        // Leaves
        const leavesGeo = new THREE.ConeGeometry(3, 6, 8);
        const leavesMat = new THREE.MeshPhongMaterial({ color: 0x0a5f0a });
        const leaves = new THREE.Mesh(leavesGeo, leavesMat);
        leaves.position.y = 4.5;
        leaves.castShadow = true;
        group.add(leaves);

        if (this.borderGroup) {
            this.borderGroup.add(group);
        } else {
            this.scene.add(group);
        }

        // Blocking Collision Box (for border trees too)
        const blockerGeo = new THREE.BoxGeometry(2, 10, 2);
        const blockerMat = new THREE.MeshBasicMaterial({ visible: false });
        const blocker = new THREE.Mesh(blockerGeo, blockerMat);
        blocker.position.set(x, y + 5, z);
        this.scene.add(blocker);
        this.platforms.push(blocker);
    }

    createCoin(x, y, z) {
        this.coins.push(new Coin(this.scene, x, y, z));
    }

    createEnemy(x, y, z, dist) {
        // Pass the loaded GLB asset
        const glb = this.assetManager.getAsset('assets/spike_top_super_mario_bros.glb');
        this.enemies.push(new Enemy(this.scene, x, y, z, dist, glb));
    }

    createGoal(x, y, z) {
        this.goalMeshGroup = new THREE.Group();
        this.goalMeshGroup.position.set(x, y, z);
        // Scale 1x (Default)

        // Simple flag pole
        const poleGeo = new THREE.CylinderGeometry(0.1, 0.1, 5);
        const poleMat = new THREE.MeshPhongMaterial({ color: 0xC0C0C0 });
        const pole = new THREE.Mesh(poleGeo, poleMat);
        pole.position.y = 2.5;
        pole.castShadow = true;
        this.goalMeshGroup.add(pole);

        // Flag
        const flagGeo = new THREE.BoxGeometry(1.5, 1, 0.1);
        const flagMat = new THREE.MeshPhongMaterial({ color: 0xFF0000 });
        const flag = new THREE.Mesh(flagGeo, flagMat);
        flag.position.set(0.75, 4.5, 0); // Local rel to group
        flag.castShadow = true;
        this.goalMeshGroup.add(flag);

        this.scene.add(this.goalMeshGroup);

        // Exact collision point
        this.goalPos = new THREE.Vector3(x, y, z);
    }

    update(dt, player) {
        // Update Coins
        if (player.mesh) {
            const playerBox = new THREE.Box3().setFromObject(player.mesh);

            this.coins.forEach(coin => {
                coin.update(dt);
                if (coin.checkCollision(playerBox)) {
                    this.score += 1;
                    document.getElementById('score').innerText = `Coins: ${this.score}`;
                }
            });

            // Update Enemies
            this.enemies.forEach(enemy => {
                enemy.update(dt);
                if (enemy.checkCollision(playerBox)) {
                    // Respawn logic
                    console.log("Hit enemy!");
                    player.mesh.position.set(0, 5, 0);
                    player.velocity.set(0, 0, 0);
                }
            });

            // Goal check
            if (player.mesh.position.distanceTo(this.goalPos) < 2) {
                // Reset keys
                player.resetKeys();

                // Show Banner
                document.dispatchEvent(new CustomEvent('level-complete', { detail: { level: this.currentLevelIndex } }));
            }
        }
    }
}
