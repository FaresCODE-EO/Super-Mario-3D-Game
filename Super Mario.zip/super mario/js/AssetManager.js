import * as THREE from 'three';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export class AssetManager {
    constructor() {
        this.assets = {};
        this.toLoad = [];
        this.objLoader = new OBJLoader();
        this.gltfLoader = new GLTFLoader(); // Init
        this.texLoader = new THREE.TextureLoader();
    }

    queueDownload(path) {
        this.toLoad.push(path);
    }

    downloadAll(callback) {
        if (this.toLoad.length === 0) {
            callback();
            return;
        }

        let loadedCount = 0;
        const total = this.toLoad.length;
        const loadingElement = document.getElementById('loading-screen');

        this.toLoad.forEach(path => {
            const onLoad = (asset) => {
                this.assets[path] = asset;
                loadedCount++;
                console.log(`Loaded: ${path}`);
                if (loadingElement) loadingElement.innerText = `Loading Assets... ${Math.floor((loadedCount / total) * 100)}%`;
                if (loadedCount === total) callback();
            };

            const onError = (err) => {
                console.error(`Failed to load ${path}`, err);
                if (loadingElement) {
                    loadingElement.style.color = 'red';
                    loadingElement.innerHTML = `Error loading ${path}<br>If you are opening html directly, use a Local Server.`;
                }
            };

            if (path.endsWith('.obj')) {
                this.objLoader.load(path, onLoad, undefined, onError);
            } else if (path.endsWith('.glb') || path.endsWith('.gltf')) {
                this.gltfLoader.load(path, onLoad, undefined, onError);
            } else if (path.endsWith('.png') || path.endsWith('.jpg')) {
                this.texLoader.load(path, onLoad, undefined, onError);
            } else {
                console.warn("Unknown asset type:", path);
                loadedCount++;
                if (loadedCount === total) callback();
            }
        });
    }

    getAsset(path) {
        return this.assets[path];
    }
}
