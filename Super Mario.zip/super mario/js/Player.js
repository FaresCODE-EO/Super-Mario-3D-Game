import * as THREE from 'three';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';

export class Player {
    constructor(scene, camera, platforms) {
        this.scene = scene;
        this.camera = camera;
        this.platforms = platforms; // Array of Box3 for now, or objects

        this.mesh = null;
        this.velocity = new THREE.Vector3();
        this.direction = new THREE.Vector3();
        this.onGround = false;
        this.speed = 10;
        this.jumpForce = 15;
        this.gravity = 30;

        // Input state
        this.keys = {
            ArrowUp: false,
            ArrowDown: false,
            ArrowLeft: false,
            ArrowRight: false,
            Space: false
        };

        this.raycaster = new THREE.Raycaster();
        this.down = new THREE.Vector3(0, -1, 0);

        this.init();
        this.addEventListeners();
    }

    resetKeys() {
        this.keys = {
            ArrowUp: false,
            ArrowDown: false,
            ArrowLeft: false,
            ArrowRight: false,
            Space: false
        };
    }

    init() {
        // Assets are now handled by AssetManager in main.js
        // The mesh is passed in via setMesh or we assume main passes it
    }

    setMesh(mesh, texture = null) {
        if (!mesh) {
            this.createFallbackMesh();
            return;
        }

        this.mesh = mesh.clone();
        this.mesh.scale.set(2.5, 2.5, 2.5); // 10x Bigger (0.25 -> 2.5)
        this.mesh.position.set(0, 5, 0);
        this.mesh.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;

                // Explicit texture override (Old behavior)
                if (texture) {
                    if (Array.isArray(child.material)) {
                        child.material.forEach(m => m.map = texture);
                    } else {
                        child.material.map = texture;
                    }
                }

                // If it has no material/map and no texture provided, default red.
                // But if it came from GLB, it likely has material.
                // Only default if material is missing/empty.
                if ((!child.material || (Array.isArray(child.material) && child.material.length === 0)) && !texture) {
                    child.material = new THREE.MeshPhongMaterial({ color: 0xff0000 });
                }
            }
        });
        this.scene.add(this.mesh);
        console.log("Player Mesh Set");
    }

    createFallbackMesh() {
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const material = new THREE.MeshPhongMaterial({ color: 0xff0000 });
        this.mesh = new THREE.Mesh(geometry, material);
        this.mesh.position.set(0, 5, 0);
        this.mesh.castShadow = true;
        this.scene.add(this.mesh);
    }

    addEventListeners() {
        window.addEventListener('keydown', (e) => {
            if (e.code === 'Space') this.keys.Space = true;
            if (e.key === 'ArrowUp' || e.code === 'KeyW') this.keys.ArrowUp = true;
            if (e.key === 'ArrowDown' || e.code === 'KeyS') this.keys.ArrowDown = true;
            if (e.key === 'ArrowLeft' || e.code === 'KeyA') this.keys.ArrowLeft = true;
            if (e.key === 'ArrowRight' || e.code === 'KeyD') this.keys.ArrowRight = true;
        });

        window.addEventListener('keyup', (e) => {
            if (e.code === 'Space') this.keys.Space = false;
            if (e.key === 'ArrowUp' || e.code === 'KeyW') this.keys.ArrowUp = false;
            if (e.key === 'ArrowDown' || e.code === 'KeyS') this.keys.ArrowDown = false;
            if (e.key === 'ArrowLeft' || e.code === 'KeyA') this.keys.ArrowLeft = false;
            if (e.key === 'ArrowRight' || e.code === 'KeyD') this.keys.ArrowRight = false;
        });
    }

    update(dt) {
        if (!this.mesh) return;

        // Movement
        this.direction.set(0, 0, 0);
        const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
        forward.y = 0;
        forward.normalize();
        const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
        right.y = 0;
        right.normalize();

        if (this.keys.ArrowUp) this.direction.add(forward);
        if (this.keys.ArrowDown) this.direction.sub(forward);
        if (this.keys.ArrowLeft) this.direction.sub(right);
        if (this.keys.ArrowRight) this.direction.add(right);

        if (this.direction.length() > 0) {
            this.direction.normalize();
            this.velocity.x = this.direction.x * this.speed;
            this.velocity.z = this.direction.z * this.speed;

            // Rotate character to face direction
            const targetRotation = Math.atan2(this.direction.x, this.direction.z);
            this.mesh.rotation.y = targetRotation;
        } else {
            this.velocity.x = 0;
            this.velocity.z = 0;
        }

        // Jumping
        if (this.keys.Space && this.onGround) {
            this.velocity.y = this.jumpForce;
            this.onGround = false;
        }

        // Gravity
        this.velocity.y -= this.gravity * dt;

        // Apply velocity
        this.mesh.position.x += this.velocity.x * dt;
        this.mesh.position.y += this.velocity.y * dt;
        this.mesh.position.z += this.velocity.z * dt;

        // Ground/Collision Check (Simple floor at y=0)
        // In a real physics engine we'd check against level platforms
        // Ground/Collision Check with Raycaster
        const rayOrigin = this.mesh.position.clone();
        rayOrigin.y += 0.5; // Start slightly above feet
        this.raycaster.set(rayOrigin, this.down);

        const intersects = this.raycaster.intersectObjects(this.platforms);

        if (intersects.length > 0) {
            const hit = intersects[0];
            // Check if close enough to stand on (0.5 offset + small tolerance)
            if (hit.distance < 0.6 && this.velocity.y <= 0) {
                this.mesh.position.y = hit.point.y;
                this.velocity.y = 0;
                this.onGround = true;
            } else {
                this.onGround = false;
            }
        } else {
            this.onGround = false;
        }

        // Respawn if fallen too far
        if (this.mesh.position.y < -30) {
            this.mesh.position.set(0, 5, 0);
            this.velocity.set(0, 0, 0);
        }

        // Simple platform collision (just floor check for now in prototype)
        // TODO: Implement actual platform collision
    }
}
